@echo off
setlocal
cd /d "%~dp0"
echo Installing PyInstaller...
py -m pip install --upgrade pyinstaller
if errorlevel 1 (
  echo Could not install PyInstaller. Check Python and internet connection.
  pause
  exit /b 1
)
echo Building ArenaClicker.exe...
py -m PyInstaller --noconfirm --clean --onefile --windowed --name ArenaClicker main.py
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo.
echo Done: dist\ArenaClicker.exe
pause
