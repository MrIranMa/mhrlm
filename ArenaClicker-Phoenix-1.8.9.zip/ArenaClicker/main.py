# Arena Clicker - Windows 10/11
# Lightweight mouse auto-clicker and click multiplier.
# Uses only Python standard library at runtime.

import os
import sys
import time
import queue
import threading
import ctypes
from ctypes import wintypes
from collections import deque
import tkinter as tk
from tkinter import ttk, messagebox

if os.name != "nt":
    raise SystemExit("Arena Clicker is designed for Windows 10/11.")

ULONG_PTR = ctypes.c_ulonglong if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_ulong
WINFUNCTYPE = getattr(ctypes, "WINFUNCTYPE", ctypes.CFUNCTYPE)

# Mouse messages
WH_MOUSE_LL = 14
WM_LBUTTONDOWN = 0x0201
WM_LBUTTONUP = 0x0202
WM_RBUTTONDOWN = 0x0204
WM_RBUTTONUP = 0x0205
WM_MBUTTONDOWN = 0x0207
WM_MBUTTONUP = 0x0208
WM_XBUTTONDOWN = 0x020B
WM_XBUTTONUP = 0x020C
WM_QUIT = 0x0012
LLMHF_INJECTED = 0x00000001
GA_ROOT = 2

# SendInput constants
INPUT_MOUSE = 0
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_MIDDLEDOWN = 0x0020
MOUSEEVENTF_MIDDLEUP = 0x0040

# Keyboard
VK_F6 = 0x75

BUTTONS = ("Left", "Right", "Middle", "Mouse4", "Mouse5")
MULTI_SOURCE_BUTTONS = ("Left + Right (separate)",) + BUTTONS
OUTPUT_BUTTONS = ("Same as input", "Left", "Right", "Middle")


class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("pt", POINT),
        ("mouseData", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ULONG_PTR),
    ]


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG),
        ("dy", wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ULONG_PTR),
    ]


class INPUTUNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT)]


class INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", wintypes.DWORD), ("u", INPUTUNION)]


HOOKPROC = WINFUNCTYPE(ctypes.c_ssize_t, ctypes.c_int, ctypes.c_size_t, ctypes.c_void_p)


def click_flags(button):
    return {
        "Left": (MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP),
        "Right": (MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP),
        "Middle": (MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP),
    }.get(button, (MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP))


class ArenaClicker:
    def __init__(self, root):
        self.root = root
        self.root.title("Arena Clicker")
        self.root.geometry("540x650")
        self.root.minsize(500, 610)
        self.root.configure(bg="#111116")

        self.user32 = ctypes.windll.user32
        self.kernel32 = ctypes.windll.kernel32
        self._configure_winapi()

        self.enabled = threading.Event()
        self.auto_pressed = threading.Event()
        self.stop_event = threading.Event()
        self.click_queue = queue.Queue()
        self.click_times = deque()
        self.click_times_lock = threading.Lock()
        self.config_lock = threading.Lock()

        self.mode = "Auto Click"
        self.trigger_button = "Mouse4"
        self.source_button = "Left + Right (separate)"
        self.output_button = "Same as input"
        self.cps = 20

        self.multiplier_down = set()
        self.hook_thread_id = None
        self.hook_handle = None
        self.hook_error = None
        self.hook_ready = threading.Event()
        self.app_hwnd = None
        self._f6_was_down = False
        self._hook_callback = HOOKPROC(self._mouse_hook)

        self._build_ui()
        self.root.update_idletasks()
        try:
            self.app_hwnd = self.user32.GetAncestor(self.root.winfo_id(), GA_ROOT)
            if not self.app_hwnd:
                self.app_hwnd = self.root.winfo_id()
        except Exception:
            self.app_hwnd = self.root.winfo_id()

        self.hook_thread = threading.Thread(target=self._hook_loop, daemon=True)
        self.hook_thread.start()
        self.worker_thread = threading.Thread(target=self._click_worker, daemon=True)
        self.worker_thread.start()

        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(150, self._poll_ui)

    def _configure_winapi(self):
        self.user32.SetWindowsHookExW.argtypes = [
            ctypes.c_int, HOOKPROC, ctypes.c_void_p, wintypes.DWORD
        ]
        self.user32.SetWindowsHookExW.restype = ctypes.c_void_p
        self.user32.CallNextHookEx.argtypes = [
            ctypes.c_void_p, ctypes.c_int, ctypes.c_size_t, ctypes.c_void_p
        ]
        self.user32.CallNextHookEx.restype = ctypes.c_ssize_t
        self.user32.UnhookWindowsHookEx.argtypes = [ctypes.c_void_p]
        self.user32.UnhookWindowsHookEx.restype = wintypes.BOOL
        self.user32.GetMessageW.argtypes = [
            ctypes.POINTER(wintypes.MSG), ctypes.c_void_p, wintypes.UINT, wintypes.UINT
        ]
        self.user32.GetMessageW.restype = ctypes.c_int
        self.user32.PostThreadMessageW.argtypes = [
            wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM
        ]
        self.user32.PostThreadMessageW.restype = wintypes.BOOL
        self.user32.SendInput.argtypes = [
            wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int
        ]
        self.user32.SendInput.restype = wintypes.UINT
        self.user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
        self.user32.GetAsyncKeyState.restype = ctypes.c_short
        self.user32.GetWindowRect.argtypes = [
            wintypes.HWND, ctypes.POINTER(wintypes.RECT)
        ]
        self.user32.GetWindowRect.restype = wintypes.BOOL
        self.user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
        self.user32.GetAncestor.restype = wintypes.HWND
        self.kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
        self.kernel32.GetModuleHandleW.restype = wintypes.HMODULE
        self.kernel32.GetCurrentThreadId.restype = wintypes.DWORD

    def _build_ui(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "Arena.TCombobox",
            fieldbackground="#24242d",
            background="#24242d",
            foreground="#f3f3f6",
            arrowcolor="#ff4b55",
            bordercolor="#3b3b46",
            lightcolor="#3b3b46",
            darkcolor="#3b3b46",
            padding=7,
        )
        style.map(
            "Arena.TCombobox",
            fieldbackground=[("readonly", "#24242d")],
            foreground=[("readonly", "#f3f3f6")],
        )
        style.configure(
            "Arena.Horizontal.TScale",
            background="#111116",
            troughcolor="#30303a",
            sliderthickness=16,
        )

        outer = tk.Frame(self.root, bg="#111116", padx=24, pady=20)
        outer.pack(fill="both", expand=True)

        tk.Label(
            outer, text="ARENA CLICKER", bg="#111116", fg="#ff4652",
            font=("Segoe UI", 22, "bold")
        ).pack(anchor="center")
        tk.Label(
            outer, text="AUTO CLICK  •  DOUBLE CLICK  •  TRIPLE CLICK",
            bg="#111116", fg="#9b9ba8", font=("Segoe UI", 8, "bold")
        ).pack(anchor="center", pady=(2, 16))

        self.status_var = tk.StringVar(value="غیرفعال  •  برای شروع F6 را بزن")
        self.status_label = tk.Label(
            outer, textvariable=self.status_var, bg="#202028", fg="#ff7078",
            font=("Tahoma", 10, "bold"), padx=12, pady=10
        )
        self.status_label.pack(fill="x", pady=(0, 16))

        panel = tk.Frame(
            outer, bg="#1a1a22", highlightbackground="#30303b",
            highlightthickness=1, padx=16, pady=14
        )
        panel.pack(fill="x")

        self.mode_var = tk.StringVar(value="Auto Click")
        self.trigger_var = tk.StringVar(value="Mouse4")
        self.source_var = tk.StringVar(value="Left + Right (separate)")
        self.output_var = tk.StringVar(value="Same as input")
        self.cps_var = tk.IntVar(value=20)

        self._add_label(panel, "حالت عملکرد")
        mode_box = ttk.Combobox(
            panel, textvariable=self.mode_var,
            values=("Auto Click", "Double Click", "Triple Click"),
            state="readonly", style="Arena.TCombobox", font=("Segoe UI", 10)
        )
        mode_box.pack(fill="x", pady=(5, 13))
        mode_box.bind("<<ComboboxSelected>>", self._config_changed)

        self._add_label(panel, "دکمه نگه‌داشتن برای Auto Click")
        trigger_box = ttk.Combobox(
            panel, textvariable=self.trigger_var, values=BUTTONS,
            state="readonly", style="Arena.TCombobox", font=("Segoe UI", 10)
        )
        trigger_box.pack(fill="x", pady=(5, 13))
        trigger_box.bind("<<ComboboxSelected>>", self._config_changed)

        self._add_label(panel, "دکمه ورودی Double / Triple (پیش‌فرض: چپ و راست مستقل)")
        source_box = ttk.Combobox(
            panel, textvariable=self.source_var, values=MULTI_SOURCE_BUTTONS,
            state="readonly", style="Arena.TCombobox", font=("Segoe UI", 10)
        )
        source_box.pack(fill="x", pady=(5, 13))
        source_box.bind("<<ComboboxSelected>>", self._config_changed)

        self._add_label(panel, "دکمه کلیک خروجی")
        output_box = ttk.Combobox(
            panel, textvariable=self.output_var, values=OUTPUT_BUTTONS,
            state="readonly", style="Arena.TCombobox", font=("Segoe UI", 10)
        )
        output_box.pack(fill="x", pady=(5, 13))
        output_box.bind("<<ComboboxSelected>>", self._config_changed)

        self._add_label(panel, "سرعت Auto Click")
        cps_row = tk.Frame(panel, bg="#1a1a22")
        cps_row.pack(fill="x", pady=(5, 0))
        self.cps_value_label = tk.Label(
            cps_row, text="20 CPS", bg="#1a1a22", fg="#ff626c",
            font=("Segoe UI", 11, "bold")
        )
        self.cps_value_label.pack(side="right")
        scale = ttk.Scale(
            cps_row, from_=1, to=25, orient="horizontal",
            variable=self.cps_var, style="Arena.Horizontal.TScale",
            command=self._cps_changed
        )
        scale.pack(side="left", fill="x", expand=True, padx=(0, 12))

        self.live_cps_var = tk.StringVar(value="0 CPS")
        live = tk.Frame(outer, bg="#111116", pady=14)
        live.pack(fill="x")
        tk.Label(
            live, text="سرعت فعلی", bg="#111116", fg="#9b9ba8",
            font=("Tahoma", 9)
        ).pack()
        tk.Label(
            live, textvariable=self.live_cps_var, bg="#111116", fg="#f4f4f7",
            font=("Segoe UI", 25, "bold")
        ).pack()

        self.toggle_button = tk.Button(
            outer, text="فعال‌سازی  (F6)", command=self.toggle_enabled,
            bg="#d93643", activebackground="#f04a56", fg="white",
            activeforeground="white", relief="flat", bd=0,
            font=("Tahoma", 11, "bold"), cursor="hand2", pady=13
        )
        self.toggle_button.pack(fill="x", pady=(0, 12))

        tk.Label(
            outer,
            text="در حالت Auto، دکمه انتخابی را نگه دار. در حالت Double/Triple، هر بار دکمه ورودی را بزن.",
            bg="#111116", fg="#a2a2ad", font=("Tahoma", 8),
            wraplength=470, justify="center"
        ).pack(fill="x")
        tk.Label(
            outer, text="F6 = فعال / توقف سریع    •    خروجی: Left / Right / Middle",
            bg="#111116", fg="#777783", font=("Segoe UI", 8)
        ).pack(pady=(8, 0))

    def _add_label(self, parent, text):
        tk.Label(
            parent, text=text, bg="#1a1a22", fg="#e8e8ed",
            font=("Tahoma", 9, "bold"), anchor="e"
        ).pack(fill="x")

    def _config_changed(self, _event=None):
        with self.config_lock:
            self.mode = self.mode_var.get()
            self.trigger_button = self.trigger_var.get()
            self.source_button = self.source_var.get()
            self.output_button = self.output_var.get()

    def _cps_changed(self, value):
        try:
            self.cps = max(1, min(25, int(float(value) + 0.5)))
            self.cps_value_label.config(text=f"{self.cps} CPS")
        except Exception:
            pass

    def toggle_enabled(self):
        if self.enabled.is_set():
            self.enabled.clear()
            self.auto_pressed.clear()
            self.status_var.set("غیرفعال  •  متوقف شد")
            self.status_label.config(fg="#ff7078")
            self.toggle_button.config(text="فعال‌سازی  (F6)", bg="#d93643")
        else:
            if self.hook_error:
                messagebox.showerror(
                    "Mouse Hook Error",
                    "اتصال به ماوس ویندوز برقرار نشد.\n"
                    "برنامه را ببند و یک بار با Run as administrator اجرا کن.\n\n"
                    + str(self.hook_error)
                )
                return
            self.enabled.set()
            self.status_var.set("فعال  •  آماده اجرا")
            self.status_label.config(fg="#78e0a0")
            self.toggle_button.config(text="توقف  (F6)", bg="#8f2630")

    def _is_over_app(self, x, y):
        if not self.app_hwnd:
            return False
        rect = wintypes.RECT()
        try:
            if not self.user32.GetWindowRect(self.app_hwnd, ctypes.byref(rect)):
                return False
            return rect.left <= x < rect.right and rect.top <= y < rect.bottom
        except Exception:
            return False

    @staticmethod
    def _button_for_message(msg, mouse_data):
        if msg in (WM_LBUTTONDOWN, WM_LBUTTONUP):
            return "Left"
        if msg in (WM_RBUTTONDOWN, WM_RBUTTONUP):
            return "Right"
        if msg in (WM_MBUTTONDOWN, WM_MBUTTONUP):
            return "Middle"
        if msg in (WM_XBUTTONDOWN, WM_XBUTTONUP):
            xbutton = (mouse_data >> 16) & 0xFFFF
            return "Mouse4" if xbutton == 1 else "Mouse5"
        return None

    @staticmethod
    def _is_down_message(msg):
        return msg in (WM_LBUTTONDOWN, WM_RBUTTONDOWN, WM_MBUTTONDOWN, WM_XBUTTONDOWN)

    @staticmethod
    def _is_up_message(msg):
        return msg in (WM_LBUTTONUP, WM_RBUTTONUP, WM_MBUTTONUP, WM_XBUTTONUP)

    def _mouse_hook(self, n_code, w_param, l_param):
        if n_code >= 0 and self.enabled.is_set():
            try:
                data = ctypes.cast(l_param, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
                if not (data.flags & LLMHF_INJECTED):
                    msg = int(w_param)
                    button = self._button_for_message(msg, data.mouseData)
                    if button:
                        with self.config_lock:
                            mode = self.mode
                            trigger = self.trigger_button
                            source = self.source_button
                            output = self.output_button

                        if mode == "Auto Click":
                            if button == trigger:
                                if self._is_down_message(msg):
                                    self.auto_pressed.set()
                                elif self._is_up_message(msg):
                                    self.auto_pressed.clear()

                        else:
                            # Left and Right can be multiplied independently.
                            source_matches = (
                                button in ("Left", "Right")
                                if source == "Left + Right (separate)"
                                else button == source
                            )
                            if source_matches:
                                if self._is_down_message(msg):
                                    if self._is_over_app(data.pt.x, data.pt.y):
                                        self.multiplier_down.discard(button)
                                    elif button not in self.multiplier_down:
                                        # Fire immediately on physical press; do not wait for release
                                        # or hand the event to a delayed worker queue.
                                        self.multiplier_down.add(button)
                                        count = 2 if mode == "Double Click" else 3
                                        target = button if output == "Same as input" else output
                                        self._send_click_burst(count, target)
                                        return 1
                                    else:
                                        return 1
                                elif self._is_up_message(msg):
                                    if button in self.multiplier_down:
                                        self.multiplier_down.discard(button)
                                        return 1
            except Exception:
                pass

        return self.user32.CallNextHookEx(
            self.hook_handle, n_code, w_param, l_param
        )

    def _hook_loop(self):
        self.hook_thread_id = self.kernel32.GetCurrentThreadId()
        module = self.kernel32.GetModuleHandleW(None)
        self.hook_handle = self.user32.SetWindowsHookExW(
            WH_MOUSE_LL, self._hook_callback, module, 0
        )
        if not self.hook_handle:
            self.hook_error = ctypes.WinError()
            self.hook_ready.set()
            return

        self.hook_ready.set()
        msg = wintypes.MSG()
        while True:
            result = self.user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
            if result <= 0:
                break
            self.user32.TranslateMessage(ctypes.byref(msg))
            self.user32.DispatchMessageW(ctypes.byref(msg))

        if self.hook_handle:
            self.user32.UnhookWindowsHookEx(self.hook_handle)
            self.hook_handle = None

    def _send_click(self, button):
        down_flag, up_flag = click_flags(button)
        for flag in (down_flag, up_flag):
            inp = INPUT()
            inp.type = INPUT_MOUSE
            inp.mi = MOUSEINPUT(0, 0, 0, flag, 0, 0)
            sent = self.user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
            if sent != 1:
                return False
            if flag == down_flag:
                time.sleep(0.003)
        return True

    def _send_click_burst(self, count, button):
        """Submit distinct down/up transitions together, with no artificial sleeps."""
        down_flag, up_flag = click_flags(button)
        events = (INPUT * (count * 2))()
        for index in range(count):
            down = INPUT()
            down.type = INPUT_MOUSE
            down.mi = MOUSEINPUT(0, 0, 0, down_flag, 0, 0)
            up = INPUT()
            up.type = INPUT_MOUSE
            up.mi = MOUSEINPUT(0, 0, 0, up_flag, 0, 0)
            events[index * 2] = down
            events[index * 2 + 1] = up
        sent = self.user32.SendInput(len(events), events, ctypes.sizeof(INPUT))
        if sent == len(events):
            for _ in range(count):
                self._record_click()
            return True
        return False

    def _record_click(self):
        now = time.monotonic()
        with self.click_times_lock:
            self.click_times.append(now)
            while self.click_times and now - self.click_times[0] > 1.0:
                self.click_times.popleft()

    def _click_worker(self):
        while not self.stop_event.is_set():
            if (
                self.enabled.is_set()
                and self.mode == "Auto Click"
                and self.auto_pressed.is_set()
            ):
                with self.config_lock:
                    output = self.output_button
                    cps = self.cps
                if output == "Same as input":
                    output = "Left"
                self._send_click(output)
                self._record_click()
                self.stop_event.wait(max(0.001, 1.0 / max(1, cps)))
                continue

            try:
                count, output = self.click_queue.get(timeout=0.02)
            except queue.Empty:
                continue

            if self.enabled.is_set():
                for _ in range(count):
                    if self.stop_event.is_set() or not self.enabled.is_set():
                        break
                    self._send_click(output)
                    self._record_click()
                    self.stop_event.wait(0.008)

    def _poll_ui(self):
        if self.stop_event.is_set():
            return

        # Global F6 toggle. Polling keeps the hotkey available even if a mouse
        # button is being intercepted by the click-multiplier mode.
        try:
            down = bool(self.user32.GetAsyncKeyState(VK_F6) & 0x8000)
            if down and not self._f6_was_down:
                self.toggle_enabled()
            self._f6_was_down = down
        except Exception:
            pass

        now = time.monotonic()
        with self.click_times_lock:
            while self.click_times and now - self.click_times[0] > 1.0:
                self.click_times.popleft()
            cps_now = len(self.click_times)

        self.live_cps_var.set(f"{cps_now} CPS")
        if self.hook_error:
            self.status_var.set("خطا در اتصال ماوس  •  اجرای مجدد با دسترسی Administrator")
            self.status_label.config(fg="#ff7078")

        self.root.after(50, self._poll_ui)

    def close(self):
        self.enabled.clear()
        self.auto_pressed.clear()
        self.stop_event.set()
        if self.hook_thread_id:
            try:
                self.user32.PostThreadMessageW(
                    self.hook_thread_id, WM_QUIT, 0, 0
                )
            except Exception:
                pass
        self.root.after(100, self.root.destroy)


def main():
    root = tk.Tk()
    app = ArenaClicker(root)
    root.mainloop()


if __name__ == "__main__":
    main()
